import { Link } from "react-router-dom";
import "./MakeRequestButton.css";

interface MakeRequestButtonProps {
  label: string;
  to?: string;
  className?: string;
}

export default function MakeRequestButton({ label, to = "/", className = "" }: MakeRequestButtonProps) {
  const content = (
    <>
      <span className="make-request-btn-text">{label}</span>
      <svg className="make-request-btn-corner" viewBox="0 0 32 32" aria-hidden>
        <path d="M 0 32 L 0 0 L 32 0" strokeWidth="2" />
      </svg>
      <svg className="make-request-btn-corner" viewBox="0 0 32 32" aria-hidden>
        <path d="M 0 32 L 0 0 L 32 0" strokeWidth="2" />
      </svg>
      <svg className="make-request-btn-corner" viewBox="0 0 32 32" aria-hidden>
        <path d="M 0 32 L 0 0 L 32 0" strokeWidth="2" />
      </svg>
      <svg className="make-request-btn-corner" viewBox="0 0 32 32" aria-hidden>
        <path d="M 0 32 L 0 0 L 32 0" strokeWidth="2" />
      </svg>
    </>
  );

  return (
    <div className={`make-request-btn-container ${className}`.trim()} style={{ ["--btn-color" as string]: "hsl(var(--secondary))" }}>
      {to ? (
        <Link to={to} className="make-request-btn">
          {content}
        </Link>
      ) : (
        <button type="button" className="make-request-btn">
          {content}
        </button>
      )}
    </div>
  );
}
